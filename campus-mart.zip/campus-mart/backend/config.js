export default {
    MONGODB_URL: process.env.MONGODB_URL || 'mongodb://localhost/campusMart',
    JWT_SECRET: process.env.JWT_SECRET || 'somethingsecret'
}